clase principal
package consola;
import logica.*;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	Nacional n;
	Fecha f1= new Fecha(12,4,2010);	
    n=new Nacional();
    n.setDepartamento("rocha");
	n.setSubsidiado(true);
	n.setNombre("silvia");
	n.setCodigo(565);
	n.setPrecioCosto(10.0);
	n.setVencimiento(f1);
    Fecha f2= new Fecha(12,5,1990);
    Importado i = new Importado (10.0,2010,"rodri",456,678.8,f2);
    System.out.println("El nacional n es:"+n.toString() );
    System.out.println("El importado i es:"+i.toString() );
}
}
clase importado

package logica;

public class Importado extends Articulo {
private double impuesto;
private int anioimportacion;

public Importado() {
	
}


public Importado(double impuesto,int anioimportacion,String nombre,int codigo, double precioCosto,Fecha vencimiento) {
	super(nombre,codigo,precioCosto,vencimiento);
	this.impuesto = impuesto;
	this.anioimportacion = anioimportacion;
}

public double getImpuesto() {
	return impuesto;
}

public void setImpuesto(double impuesto) {
	this.impuesto = impuesto;
}

public int getAnioimportacion() {
	return anioimportacion;
}

public void setAnioimportacion(int anioimportacion) {
	this.anioimportacion = anioimportacion;
}


@Override
public String toString() {
	return super.toString() + " impuesto=" + impuesto + ", anioimportacion=" + anioimportacion ;
}

@Override
public double precioVenta() {
double total= super.precioVenta();
if (anioimportacion<=(2008))
	return (total+impuesto*0.80); 
	else 
		return (impuesto);
	
}
}
clase nacional
package logica;

public class Nacional extends Articulo {
	
		private String departamento;
		private boolean subsidiado;

		public Nacional() {
			
		}

		public Nacional(String departamento,boolean subsidiado,String nombre,int codigo, double precioCosto,Fecha vencimiento) {
			super(nombre,codigo,precioCosto,vencimiento);
			this.departamento = departamento;
			this.subsidiado = subsidiado;
		}

		public String getDepartamento() {
			return departamento;
		}

		public void setDepartamento(String departamento) {
			this.departamento = departamento;
		}

		public boolean isSubsidiado() {
			return subsidiado;
		}

		public void setSubsidiado(boolean subsidiado) {
			this.subsidiado = subsidiado;
		}
		

		@Override
		public String toString() {
			return super.toString() +  " departamento=" + departamento + ", subsidiado=" + subsidiado  ;
		}

		@Override
		public double precioVenta() {
		double total= super.precioVenta();
		if (subsidiado) 
			return total;
		else { 
			if (departamento.equals("Montevideo"))
				return (total*1.15);
			else
				return (total*1.10);
}
		
		}
		
}
		
clase fecha
package logica;

public class Fecha {
	
	private int dia;
	private int mes;
	private int anio;
	
	public Fecha ()	{
		
	}

	public Fecha (int d, int m, int a)	{
		
		this.dia = d;
		this.mes = m;
		this.anio = a;
	}
	
	
	
	public void setDia (int d)	{
		
		dia = d;
	}
	public void setMes (int m)	{
		
		mes = m;
	}
	public void setAnio (int a)	{
		
		anio = a;
	}
	
		
	public int getDia ()	{
		
		return dia;
	}
	public int getMes ()	{
		
		return mes;
	}
	public int getAnio ()	{
		
		return anio;
	}
	
	@Override
	public String toString (){
				
		return dia+ "/" + mes+ "/" + anio;
	}
	
	////////////////////////////////////////////
	
	
	private boolean esBisiesto ()	{
		
		return ((anio % 4 == 0) && (anio % 100 != 0) || (anio %400 == 0));		
	}

	public boolean fechaCorrecta ()	{

		boolean diaCorrecto, mesCorrecto, anyoCorrecto;

		anyoCorrecto = (anio > 0);
		mesCorrecto = (mes >= 1) && (mes <= 12);

		switch (mes)	{

			case 2:

				if (esBisiesto ())	{

					diaCorrecto = (dia >= 1 && dia <= 29);

				} else	{

					diaCorrecto = (dia >= 1 && dia <= 28);
		}
			break;

			case 4:
			case 6:
			case 9:
			case 11:
					
				diaCorrecto = (dia >= 1 && dia <= 30);
				
				break;
		default:

			diaCorrecto = (dia >= 1 && dia <= 31);
		}

		return diaCorrecto && mesCorrecto && anyoCorrecto;

	}
	
public void diaSiguiente2 ()	{

		
		switch (mes)	{

			case 2:

				if (esBisiesto ()&& dia < 29)	{

					dia = dia+1;

				} else	{

					dia=1;
					mes=3;
				}
				break;

			case 4:
			case 6:
			case 9:
			case 11:
					
				if(dia < 30)
					dia=dia+1;
				else{

					dia=1;
					mes=mes+1;
				}
					
				
				break;
		default:

			if(dia < 31)
				dia=dia+1;
			else{

				dia=1;
				mes=mes+1;
			}
				
		}
		if (mes == 13) {
	        mes = 1;
	        anio++;
	      }

		

	}
	
}
clase articulo
package logica;

public class Articulo {
	//atributos
			private String nombre;
			private int codigo;
			private double precioCosto;
	        private Fecha vencimiento;
	        
		//constructor por defecto
			public 	Articulo() {
				nombre = null;
				codigo = 0;
				precioCosto = 0.0;
				vencimiento= new Fecha();
			}

			// constructor especifico
			public Articulo(String nom, int cod, double precio, Fecha venc) {
				nombre = nom;
				codigo = cod;
				precioCosto = precio;
				vencimiento= venc;
			}

		

			// getter y setter get:obtener y set:poner
			public String getNombre() {
				return nombre;
			}

			public void setNombre(String nombre) {
				this.nombre = nombre;
			}

			public int getCodigo() {
				return codigo;
			}

			public void setCodigo(int cod) {
				codigo = cod;
			}

			public double getPrecioCosto() {
				return precioCosto;
			}

			public void setPrecioCosto(double precio) {
				precioCosto = precio;
			}
			
			public Fecha getVencimiento() {
				return vencimiento;
			}

			public void setVencimiento(Fecha vencimiento) {
				this.vencimiento = vencimiento;
			}

			public Articulo(Fecha vencimiento) {
				super();
				this.vencimiento = vencimiento;
			}

			// metodos específicos
			public double precioVenta() {
		    
				 
			double monto;
				
			monto = precioCosto * 0.20 + precioCosto;
				
			return monto;
			}
			public boolean estaVencido(Fecha f) {
			boolean vence=false;	
			if(f.getMes()-vencimiento.getMes()>6)
			vence=true;
			return vence;
			}
				
				// metodos específicos

			// toString
			@Override
			public String toString() {
				return "nombre= "+ nombre +", codigo=" +codigo + ", precioCosto="+precioCosto +" , vencimiento=" +vencimiento.toString();

			

		}
}