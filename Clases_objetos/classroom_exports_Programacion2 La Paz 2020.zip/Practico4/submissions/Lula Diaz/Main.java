package consola;
import logica.*;
public class Principal {

public static void main(String[] args) {
// TODO Auto-generated method stub

Nacional n;
Fecha f1= new Fecha(27,7,2012); 
    n=new Nacional();
    n.setDepartamento("colonia");
n.setSubsidiado(true);
n.setNombre("Lourdes");
n.setCodigo(565);
n.setPrecioCosto(10.0);
n.setVencimiento(f1);
    Fecha f2= new Fecha(09,8,1890);
    Importado i = new Importado (10.0,2010,"rodri",456,678.8,f2);
    System.out.println("El nacional n es:"+n.toString() );
    System.out.println("El importado i es:"+i.toString() );
}
}