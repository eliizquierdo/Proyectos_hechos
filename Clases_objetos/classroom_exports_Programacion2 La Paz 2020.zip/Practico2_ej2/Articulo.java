public class Articulo{
  
  
}