
public class Main {

	public static void main(String[] args) {
		
		Articulo a=new Articulo();
		Articulo b;
		b=new Articulo(12, "pablo", 233);
		System.out.println("Articulo a="+ a.toString()+"Precio Venta= "+a.precioVenta());
		System.out.println("Articulo b="+ b.toString()+"Precio Venta= "+b.precioVenta());
		
	}

}
