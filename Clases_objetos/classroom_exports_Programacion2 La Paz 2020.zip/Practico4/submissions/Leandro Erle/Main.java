class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	Nacional n;
	Fecha f1= new Fecha(12,4,2010);	
    n=new Nacional();
    n.setDepartamento("rocha");
	n.setSubsidiado(true);
	n.setNombre("silvia");
	n.setCodigo(565);
	n.setPrecioCosto(10.0);
	n.setVencimiento(f1);
    Fecha f2= new Fecha(12,5,1990);
    Importado i = new Importado (10.0,2010,"rodri",456,678.8,f2);
    System.out.println("El nacional n es:"+n.toString() );
    System.out.println("El importado i es:"+i.toString() );
}
}
    
    
  
