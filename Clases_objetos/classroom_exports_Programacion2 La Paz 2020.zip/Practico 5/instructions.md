  

**Ejercicio 1 (**_obligatorio_**)**

 

  **Observación**: Recordar que las clases **Articulo**, **Nacional**, **Importado** y **Fecha** ya las tiene hecha del practico anterior, solo tiene que copiarlas al archivo correspondiente.

                          

 

La clase a implementar  es **Productos** que tendrá los métodos de las tablas de arriba.

  

En la clase **Main** cargar varios objetos de Nacional e Importado, comprobar que todos los métodos funcionan de manera correcta.

 

