public class Moto extends Vehiculo {
	
		private int cilindrara;
		private double precio;
		private String marca;
				

		public Moto(String marca, double precio, String matricula, Fecha fechaCompra, int cilindrara, double precio2,
				String marca2) {
			super(marca, precio, matricula, fechaCompra);
			this.cilindrara = cilindrara;
			precio = precio2;
			marca = marca2;
		}




		public double getPrecio() {
			return precio;
		}




		public void setPrecio(double precio) {
			this.precio = precio;
		}




		public String getMarca() {
			return marca;
		}




		public void setMarca(String marca) {
			this.marca = marca;
		}




		public int getCilindrara() {
			return cilindrara;
		}




		public void setCilindrara(int cilindrara) {
			this.cilindrara = cilindrara;
		}

		public double descuentoNeto() {
			double  descuentoNeto;
			
			if (cilindrara<100) 
			
				descuentoNeto = precio*0.10;
			else
				descuentoNeto=precio;
					
			return descuentoNeto;
			}




		@Override
		public String toString() {
			return "Moto [cilindrara=" + cilindrara + ", precio=" + precio + ", marca=" + marca + "]";
		}


		
		
		
}
