
import java.util.Scanner;
class Main {

	public static void main(String[] args) {
		System.out.println("Hola mundo!");
		String nombre;
		int edad;
		Scanner tecla= new Scanner(System.in);
		
		System.out.println("¿Cómo es su nombre?");
		nombre= tecla.nextLine();
		System.out.println("¿Cuál es su edad?");
		edad= tecla.nextInt();
		
		System.out.println("Su nombre es: " + nombre + " y su edad es: " + edad );
		
		
		

	}

}
