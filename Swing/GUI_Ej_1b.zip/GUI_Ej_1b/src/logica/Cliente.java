package logica;

public class Cliente {
    private String cedula;
    private int edad;
    private int antiguedad;
    private double sueldo;

    public Cliente() {
    }

    public Cliente(String cedula, int edad, int antiguedad, double sueldo) {
        this.cedula = cedula;
        this.edad = edad;
        this.antiguedad = antiguedad;
        this.sueldo = sueldo;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    /* Métodos específicos */
    
    public boolean darTarjeta(){
        boolean tieneCredito = false;
        // Doy tarjeta a una persona mayor de edad, con 6 meses 
        // de antiguedad y un sueldo mayor a 15.000
        return tieneCredito;
    }
    
    public double saldoTarjeta(){
        double saldo = 0;
        /**
         * Si el sueldo es menor a 20.000, se otorga un 35% del sueldo como saldo
         * Si el sueldo es menor a 30.000, se otorga un 50% del sualdo como saldo
         * Si el sueldo es mayor a 30.000, se otorga un 75% del sueldo como saldo
         */
        return saldo;
    }
    
    @Override
    public String toString() {
        return "Cliente{" + "cedula=" + cedula + ", edad=" + edad + ", antiguedad=" + antiguedad + ", sueldo=" + sueldo + '}';
    }
    
    
    
}
