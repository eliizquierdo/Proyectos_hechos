import java.util.Scanner;
class Main {
  
  public static void main(String[] args) {
  int num1;
	int num2;
	num1= 0;
	num2= 0;
	System.out.println("Ingrese los 2 valores que quiere calcular ");
  Scanner tecla= new Scanner(System.in);
    num1=tecla.nextInt();
    num2=tecla.nextInt();
    Calculadora p=new Calculadora();
    int result1= p.suma(num1,num2);
    System.out.println("El resultado de la suma es: "+result1);
    int result2= p.resta(num1,num2);
    System.out.println("El resultado de la resta es: "+result2);
    int result3= p.multiplica(num1,num2);
    System.out.println("El resultado de la multiplicacion es: "+result3);
    float result4= p.divide(num1,num2);
    System.out.println("El resultado de la division es: "+result4);
    float result5= p.resto(num1,num2);
    System.out.println("El resultado del resto es: "+result5);
  }
}