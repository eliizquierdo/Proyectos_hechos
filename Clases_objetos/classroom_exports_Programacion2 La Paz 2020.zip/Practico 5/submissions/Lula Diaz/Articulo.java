package logica;

public class Articulo {

private String nombre;
private int codigo;
private double precioCosto;
        private Fecha vencimiento;
        

public  Articulo() {
nombre = null;
codigo = 0;
precioCosto = 0.0;
vencimiento= new Fecha();
}

// constructor especifico
public Articulo(String nom, int cod, double precio, Fecha venc) {
nombre = nom;
codigo = cod;
precioCosto = precio;
vencimiento= venc;
}



public String getNombre() {
return nombre;
}

public void setNombre(String nombre) {
this.nombre = nombre;
}

public int getCodigo() {
return codigo;
}

public void setCodigo(int cod) {
codigo = cod;
}

public double getPrecioCosto() {
return precioCosto;
}

public void setPrecioCosto(double precio) {
precioCosto = precio;
}
public Fecha getVencimiento() {
return vencimiento;
}

public void setVencimiento(Fecha vencimiento) {
this.vencimiento = vencimiento;
}

public Articulo(Fecha vencimiento) {
super();
this.vencimiento = vencimiento;
}


public double precioVenta() {
    
 
double monto;
monto = precioCosto * 0.20 + precioCosto;
return monto;
}
public boolean estaVencido(Fecha f) {
boolean vence=false; 
if(f.getMes()-vencimiento.getMes()>6)
vence=true;
return vence;
}


// toString
@Override
public String toString() {
return "nombre= "+ nombre +", codigo=" +codigo + ", precioCosto="+precioCosto +" , vencimiento=" +vencimiento.toString();


}
}