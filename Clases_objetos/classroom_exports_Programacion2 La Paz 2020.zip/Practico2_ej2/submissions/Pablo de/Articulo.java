

public class Articulo {
	private int codigo;
	private String nombre;
	private double precioCosto;
	
	public Articulo() {
		codigo=0;
		nombre=null;
		precioCosto=0.0;

	}
	
	public Articulo(int codigo, String nombre, double precioCosto) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.precioCosto = precioCosto;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioCosto() {
		return precioCosto;
	}

	public void setPrecioCosto(double precioCosto) {
		this.precioCosto = precioCosto;
	}
	
	public double precioVenta() {
		double precioVenta;
		precioVenta=precioCosto+precioCosto*0.20;
		return precioVenta;	
	}

	@Override
	public String toString() {
		return "Articulo [codigo=" + codigo + ", nombre=" + nombre + ", precioCosto=" + precioCosto + "]";
	}
