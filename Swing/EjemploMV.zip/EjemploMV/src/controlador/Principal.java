package controlador;
//En esta versi�n no se utiliza el controlador para simplificar c�digo

import vista.*;

public class Principal {
	public static void main(String[] args){
		MenuPrincipal mp=new MenuPrincipal();
		mp.setVisible(true);
		
	}
}
