
public class main1 {

	public static void main(String[] args) {
		Vehiculo a=new Vehiculo();
		Vehiculo b=new Vehiculo();
		
		System.out.println("vehiculo a= "+a.toString());
		
		System.out.println("vehiculo b= "+b.toString());

	}

}
