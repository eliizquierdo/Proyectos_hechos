A) Diseñar la siguiente ventana, respetando los nombres de los componentes de acuerdo con la convención.

 

B)Realizar un programa que reciba un valor en grados Celsius, y lo convierta a Kelvin (oC+273) y a Fahrenkeit (oC *1.8+32), tal como muestra la figura 1. Utilizar valores de tipo double, puede utilizar la función round de la clase Math, la cual redondea el resultado hacia el entero más próximo. Los botones Limpiar y Salir son iguales al teórico.