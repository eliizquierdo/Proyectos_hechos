  public class Articulo {
	//atributos
		private String nombre;
		private int codigo;
		private double precioCosto;

	//constructor por defecto
		public 	Articulo() {
			nombre = null;
			codigo = 0;
			precioCosto = 0.0;

		}

		// constructor especifico
		public Articulo(String nom, int cod, double precio) {
			nombre = nom;
			codigo = cod;
			precioCosto = precio;
		}

		// getter y setter get:obtener y set:poner
		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int cod) {
			codigo = cod;
		}

		public double getPrecioCosto() {
			return precioCosto;
		}

		public void setPrecioCosto(double precio) {
			precioCosto = precio;
		}
		// metodos específicos
		public double precioVenta() {
		double monto;
			
		monto = precioCosto * 0.20 + precioCosto;
			
		return monto;
		}

		// metodos específicos

		// toString
		@Override
		public String toString() {
			return "nombre= "+ nombre +"codigo=" +codigo + ",precioCosto="+precioCosto;

		

	}
}