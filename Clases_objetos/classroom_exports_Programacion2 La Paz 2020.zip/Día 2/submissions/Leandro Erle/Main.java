public class Main {

	public static void main(String[] args) {
		Fecha f1= new Fecha(12,4,2010);
		Fecha f2= new Fecha(62,6,2014);
		Fecha f3= new Fecha(72,6,2016);
		Libro b;	
	    b=new Libro("azucar",100,"Lucas alias el rengo",f1);
	    Infantil d;
	    d=new Infantil("nes cafe",222,"Moria","negro",f2);
	    Libro a = new Libro ("cocoa",34,"Karateca Javier",f3); 
	   System.out.println(b.toString());
	   System.out.println("El titulo de b es:"+ b.getTitulo());
	   System.out.println("a es: "+ a.precioVenta());
	   System.out.println(d.toString());
	 
	 }

}
