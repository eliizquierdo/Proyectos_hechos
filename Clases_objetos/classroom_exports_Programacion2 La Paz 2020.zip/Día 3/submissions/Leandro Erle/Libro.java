public class Libro {
	//atributos
	private String titulo;
	private int cantPaginas;
	private String autor;
	private Fecha  creacion;
	
	//constructor por defecto
	public 	Libro() {
	titulo = null;
	cantPaginas = 0;
	autor = null;
	creacion= new Fecha();
	}
	// constructor especifico
	public Libro(String tit, int cant,String aut,Fecha crea) {
	titulo = tit;
	cantPaginas= cant;
	autor= aut;
	creacion=crea;
    }
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getCantPaginas() {
		return cantPaginas;
	}
	public void setCantPaginas(int cantPaginas) {
		this.cantPaginas = cantPaginas;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	public Fecha getCreacion() {
		return creacion;
	}
	public void setCreacion(Fecha creacion) {
		this.creacion = creacion;
	}
	public double precioVenta() {
    
    double monto;
    if (cantPaginas<100)
    	monto = 50;
    else
    	
        monto=200;

    return monto;



}
	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", cantPaginas=" + cantPaginas + ", autor=" + autor +" creacion= "+ creacion.toString();
	}
	

}


