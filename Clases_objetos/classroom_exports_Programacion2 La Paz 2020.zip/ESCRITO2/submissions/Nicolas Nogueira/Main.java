public class Main {

	public static void main(String[] args) {
		Fecha f1= new Fecha(20,9,2009);
		Fecha f2= new Fecha(10,7,2014);
		Fecha f3= new Fecha(2,8,2015);
		Fecha f4= new Fecha(25,2,2004);
		
		
		Vehiculo a = new Vehiculo("pininifarina", 200, "AAA 111", f1);
		Vehiculo b = new Vehiculo("mitsubichi", 300, "BBB 222", f2);
		Moto c = new Moto(200,"kawazaki", 290, "CC 33", f3);
		Moto d = new Moto(500,"ninja", 290, "AA 01", f4);
		
		
		System.out.println("Vehiculo 2: "+b.toString());
		System.out.println("Vehiculo 1: "+a.toString());
		System.out.println("Moto 1: "+c.toString());
		System.out.println("Moto 2: "+d.toString());
	}

}
