import java.util.Random;

public class Persona {

	private String apellido;
	private int edad;
	private double altura; 
	private long cedula;
	private char sexo;
	private double peso;

	//constructor por defecto
public 	Persona() {
	
}


//constructor especifico
public Persona (String ape, int ed, double alt, long ced, char s, double p) {
	
	this.apellido= ape;
	this.edad= ed;
	this.altura= alt;
	this.cedula= ced;
	this.sexo= s;
	this.peso= p;
	
}
	
	
	public String getApellido() {
	return apellido;
}

	public void setApellido(String ape) {
	this.apellido = ape;
}
	
	public int getEdad() {
		return edad;
		
	}
	
	public void setEdad(int ed){
		this.edad= ed;
	}
	
	public double getAltura() {
		return altura;
		
	}
	
	public void setAltura(double alt){
		this.altura= alt;
	}
	
	public long getCedula() {
		return cedula;
		
	}
	
	public void setCedula(long ced){
		this.cedula= ced;
	}
	
	public char getSexo() {
		return sexo;
		
	}
	
	public void setSexo(char s){
		this.sexo= s;
	}
	
	public double getPeso() {
		return sexo;
		
	}
	
	public void setPeso(int p){
		this.peso= p;
	}
	
	public String toString() {
		return "apellido= "+apellido + "edad= " +edad + "altura= " +altura + "cedula= " +cedula + "sexo= " +sexo + "peso= " +peso; 

	}
	
	//Es mayor con boolean
	public boolean esMayor() {
		boolean mayor=false;
		
		if (edad>=18)
			mayor=true;
			
			
		return mayor;
	}
	
	
	public void generarCI() {
		Random azar=new Random();
		cedula=6000000+azar.nextInt(1000000);

	}
	
	public int calcularIMC() {
		int resul=0;
		double imc=peso/(altura*altura);
		if (imc<20)
			resul=-1;
		else 
			if(imc<25)
					resul=0;
			else 
				resul=1;
		return resul;
	}
	
	
}
