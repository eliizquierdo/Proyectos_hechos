class Main {
  public static void main(String[] args) {
		Convertidor miVentanaOper=new Convertidor();
		miVentanaOper.setVisible(true);
  }
}