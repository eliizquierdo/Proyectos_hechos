
public class Main {

	public static void main(String[] args) {
		Listadelibros listado= new Listadelibros();
		Fecha f1= new Fecha(12,4,2010);
		Fecha f2= new Fecha(62,6,2014);
		Fecha f3= new Fecha(72,6,2016);
		Libro b;	
	    b=new Libro("azucar",100,"Lucas alias el rengo",f1);
	    Infantil d;
	    d=new Infantil("nes cafe",222,"Moria","negro",f2);
	    Libro a = new Libro ("cocoa",34,"Karateca Javier",f3); 
	   System.out.println(b.toString());
	   System.out.println("El titulo de b es:"+ b.getTitulo());
	   System.out.println("a es: "+ a.precioVenta());
	   System.out.println(d.toString());
	   Libro z = new Libro("rico",19,"tintin",f1);
	   listado.insertar(z);
	   listado.insertar(b);
	   listado.insertar(d);
	   System.out.println("Los datos del listado son:"+ listado.toString());
	   System.out.println("La cantidad de elementos son:"+ listado.cantidad());
	   Libro l8= new Libro();
	   System.out.println("el objeto l8 esta:"+ listado.pertenece(l8));
	   System.out.println("El libro que esta en el lugar 2 esta:"+ listado.devolver(2));
	   listado.remover(b);
	   System.out.println("Los datos del listado son:"+ listado.toString());
	 }

}
