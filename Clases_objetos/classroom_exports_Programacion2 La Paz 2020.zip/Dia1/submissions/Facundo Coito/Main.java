class Main {
   public static void main(String[] args) {
	Publicacion p1= new Publicacion("Boxeo",2020);


	System.out.println(p1.toString());
	System.out.println("El nombre de p1 es:"+getnombre));
	System.out.println("p1 es"+p1.precio());
	
  }
}