
public class Articulo {
		
	private int codigo;
	private String nombre;
	private double precioCosto;
		
	public Articulo() {
			
	}
		
	public Articulo(int codigo, String nombre, double precioCosto) {
			this.codigo = codigo;
			this.nombre = nombre;
			this.precioCosto = precioCosto;
	}
		
		

	public int getCodigo() {
			return codigo;
	}

	public void setCodigo(int codigo) {
			this.codigo = codigo;
	}

	public String getNombre() {
			return nombre;
	}

	public void setNombre(String nombre) {
			this.nombre = nombre;
	}

	public double getPrecioCosto() {
			return precioCosto;
	}

	public void setPrecioCosto(double precioCosto) {
			this.precioCosto = precioCosto;
	}
		
	/////////////////////////////////////////////

		public double precioVenta() {
			double precioVenta;
			precioVenta = precioCosto + (precioCosto*20/100);
			return precioVenta;
		}
		
		public void pedirDatos() {
			Scanner tecla = new Scanner(System.in);
			
			System.out.println("Ingrese codigo: ");
			setCodigo(tecla.nextInt());
			System.out.println("Ingrese nombre: ");
			setNombre(tecla.next());
			System.out.println("Ingrese precio de compra: ");
			setPrecioCosto(tecla.nextDouble());
		}
		
		public String toString() {
			return "Codigo: " + codigo + "\nNombre: " + nombre + "\nPrecio de venta: " + precioVenta();
		}
}