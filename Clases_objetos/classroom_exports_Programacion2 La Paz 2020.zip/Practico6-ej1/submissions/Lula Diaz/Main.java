package ejer;

public class Main {

	public static void main(String[] args) {
		Ejercicio1 miVentana=new Ejercicio1();
		miVentana.setVisible(true);

	}

}
