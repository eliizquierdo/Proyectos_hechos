package ejer2;

import java.util.Scanner;

import ejer1.Fecha1;

public class main {
	

	public static void main(String[] args) {
		
		Articulo1 a1 = new Articulo1(11,"Cuaderno",23.45);
		Articulo1 a2 = new Articulo1();
		Scanner tecla = new Scanner(System.in);
			
		System.out.println("Articulo 2");
		a2.pedirDatos();
		
		System.out.println("Resultado");
		System.out.println("");
		System.out.println(a1.toString());
		System.out.println("");
		System.out.println(a2.toString());
		System.out.println("");
		if (a1.equals(a2)) {
			System.out.println("El articulo esta VENCIDO");
		}
		else {
			System.out.println("El aticulo no esta VENCIDO");
		}
		
	}

}