import java.util.ArrayList;
public class Listadelibros {

	
	
	
	private ArrayList <Libro> lista;
	  
	public Listadelibros() {
	lista=new ArrayList<>();	
		
}
	public void insertar(Libro a) {
	lista.add(a);
	
	}	
	
	public void remover(Libro a) {
		lista.remove(a);
		
		}	
	public Libro devolver(int i) {
		return lista.get(i);
		
		}	
	
	public boolean pertenece(Libro a) {
		return lista.contains(a);
		
		}	
	
		
	
	
	public int cantidad() {
		return lista.size();
		
		}	
	@Override
	public String toString() {
		return "Listadelibros [lista=" + lista + "]";
	}
	
}