public class Main {

	public static void main(String[] args) {
		Articulo a;
		a=new Articulo();  //cree el objeto a de tipo Articulo
		
		Articulo b;
	
	    b=new Articulo("azucar",100,40.5);
		
		System.out.println("El articulo a es:"+a.toString() );
		System.out.println("El articulo b queda: "+b.toString());
		b.setNombre("yerba");
		System.out.println("El articulo b queda: "+b.getNombre());
		
	}
}