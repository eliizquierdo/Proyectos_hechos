import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		
		Articulo a1 = new Articulo(11,"Cuaderno",23.45);
		Articulo a2 = new Articulo();
		Scanner tecla = new Scanner(System.in);
			
		System.out.println("Articulo 2");
		a2.pedirDatos();
		
		System.out.println("Resultado");
		System.out.println("");
		System.out.println(a1.toString());
		System.out.println("");
		System.out.println(a2.toString());
		System.out.println("");
		if (a1.equals(a2)) {
			System.out.println("Los articulos tienen el mismo codigo!");
		}
		else {
			System.out.println("Los articulos no tienen el mismo codigo.");
		}
		
	}

}