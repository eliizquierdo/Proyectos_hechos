public class Importado extends Articulo {
private double impuesto;
private int anioimportacion;

public Importado() {
	
}


public Importado(double impuesto,int anioimportacion,String nombre,int codigo, double precioCosto,Fecha vencimiento) {
	super(nombre,codigo,precioCosto,vencimiento);
	this.impuesto = impuesto;
	this.anioimportacion = anioimportacion;
}

public double getImpuesto() {
	return impuesto;
}

public void setImpuesto(double impuesto) {
	this.impuesto = impuesto;
}

public int getAnioimportacion() {
	return anioimportacion;
}

public void setAnioimportacion(int anioimportacion) {
	this.anioimportacion = anioimportacion;
}


@Override
public String toString() {
	return super.toString() + " impuesto=" + impuesto + ", anioimportacion=" + anioimportacion ;
}

@Override
public double precioVenta() {
double total= super.precioVenta();
if (anioimportacion<=(2008))
	return (total+impuesto*0.80); 
	else 
		return (impuesto);
	
}
}



