package logica;

public class Nacional extends Articulo {
private String departamento;
private boolean subsidiado;

public Nacional() {
}

public Nacional(String departamento,boolean subsidiado,String nombre,int codigo, double precioCosto,Fecha vencimiento) {
super(nombre,codigo,precioCosto,vencimiento);
this.departamento = departamento;
this.subsidiado = subsidiado;
}

public String getDepartamento() {
return departamento;
}

public void setDepartamento(String departamento) {
this.departamento = departamento;
}

public boolean isSubsidiado() {
return subsidiado;
}

public void setSubsidiado(boolean subsidiado) {
this.subsidiado = subsidiado;
}

@Override
public String toString() {
return super.toString() +  " departamento=" + departamento + ", subsidiado=" + subsidiado  ;
}

@Override
public double precioVenta() {
double total= super.precioVenta();
if (subsidiado) 
return total;
else { 
if (departamento.equals("Montevideo"))
return (total*1.15);
else
return (total*1.10);
}
}
}