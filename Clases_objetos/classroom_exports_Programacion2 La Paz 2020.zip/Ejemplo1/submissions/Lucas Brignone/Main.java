class Main {
  public static void main(String[] args) {
    System.out.println("Hola mundo!!");
    Scanner teclado = new Scanner (System.in);
    String nom;
    int edad;
    
    System.out.println("¿Cual es tu nombre?");
    nom = teclado.nextLine();
    System.out.println("¿ ");
    edad = teclado.nextLine();
    
    
    
  }
}