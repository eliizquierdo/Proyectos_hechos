public class Vehiculo {
 private String marca;
 private double precio;
 private int matricula;

 //constructor por defecto
 public Vehiculo() {
anio=2010;	
}

 //constructor especifico
public Vehiculo(String m, double p,int a)	{
	marca=m;
	precio=p;
	matricula=m;
	
   }
//metodos getter
 public String getMarca()  {
	 return marca;
 }
 
 public double getPrecio() {
	 return precio;
 }
 public int getMatricula()    {
	 return matricula;
 }
 

 //metodo setter
 public void setMarca(String m) {
	 marca=m;
 }
 public void setPrecio(double p) {
	 precio=p;
 }
 public void setMatricula(int m) {
	 matricula=m;
 }
 public String setMarca() {
	 return marca;
 }
 
 public double setPrecio() {
	 return precio;
	
 }
 public int setMatricula()  {
	 return matricula;
 }
 
 //metodo especifico
 //si el precio es> 10000 el descuento sea de un 10% del precio
 // si no es un 50% del precio
 public double patente() {
	double precio;
	if (anio<2013)
	   patente=precio*10/100;
	else
		patente=precio*50/100;
	
	return patente;
	
 }
 
 
 @Override
 public String toString()  {
	return "Marca: "+ marca +" \nPrecio: "+ precio + "\nMatricula: " +matricula;
	
}
}