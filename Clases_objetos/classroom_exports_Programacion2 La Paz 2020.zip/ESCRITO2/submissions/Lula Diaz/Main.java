public class Main {
	public static void main(String[] args){
		
		   
		   Fecha hoy = new Fecha (12,5,2009);
		   Vehiculo f1 = new Vehiculo("W",5555,"AAC002",hoy);
		   Vehiculo F2 = new Vehiculo("P2",5555,"AAC002",hoy);		  
   
		   Moto M1 = new Moto (57,15233,"pe");
		   Moto M2 = new Moto (120,133,"pepe");
		   
		   System.out.println(f1);
		   System.out.println(F2);
		   System.out.println(M1);
		   System.out.println(M2);
		}
	

}
