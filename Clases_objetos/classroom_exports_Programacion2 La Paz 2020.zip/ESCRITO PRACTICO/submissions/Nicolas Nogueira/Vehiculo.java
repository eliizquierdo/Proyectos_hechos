//Pablo de Melo y Marcos Nogueira de Mello
public class Vehiculo {
	private String matricula;
	private String marca;
	private double precio;
	
	
	
	public Vehiculo(String matricula, String marca, double precio) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.precio = precio;
	}
	public Vehiculo(){
		
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	public double descontarPatente(){
		double descontarPatente = 0;
		if (precio>10000){
			descontarPatente=precio*0.10;
		}
		
		return descontarPatente;
	}
	
	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", marca=" + marca + ", precio=" + precio + "]";
	}
	

}