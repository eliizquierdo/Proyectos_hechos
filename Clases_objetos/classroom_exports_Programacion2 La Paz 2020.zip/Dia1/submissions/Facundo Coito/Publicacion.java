class Publicacion {

	private String nombre;
	private int anioEdicion;


 //Constructor por defecto
 public Publicacion () {
 }
 
//Constructor especifico
public Publicacion (String nom, int anioE) {
	
 nombre=nom;
 anioEdicion=anioE;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public int getAnioEdicion() {
	return anioEdicion;
}
public void setAnioEdicion(int anioEdicion) {
	this.anioEdicion = anioEdicion;
	
}

//Metodo especifico
public double precio() {
	double monto;
 if (anioEdicion<2000)

    monto=100;
else
	monto=200;
 
	return monto;
	
	
	
	
	
	
}



public String toString() {
	return "Publicacion [nombre=" + nombre + ", anioEdicion=" + anioEdicion + "]";
}


}
