public class file_2 extends file_1 {
private int CodigoCosmetico;
private boolean toxico;


 

public int getCodigoCosmetico() {
return CodigoCosmetico;
}

public void setCodigoCosmetico(int codigoCosmetico) {
CodigoCosmetico = codigoCosmetico;
}

public boolean isToxico() {
return toxico;
}

public void setToxico(boolean toxico) {
this.toxico = toxico;
}

public file_2 (String Nombre, double Precio, file_3 FechaVencimiento, int CodigoCosmetico, Boolean Toxico ) {
super(Nombre,Precio,FechaVencimiento);
this.CodigoCosmetico = CodigoCosmetico;
this.toxico = Toxico;
 }
 
@Override
public String toString() {
return super.toString() + "Cosmeticos [CodigoCosmetico=" + CodigoCosmetico + ", toxico=" + toxico.toString() + "]";
}  


 }
