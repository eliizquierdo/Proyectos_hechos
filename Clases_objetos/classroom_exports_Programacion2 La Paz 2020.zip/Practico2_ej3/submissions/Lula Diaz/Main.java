
public class Main {

	public static void main(String[] args) {
		Persona p1=new Persona();
		Persona p2=new Persona("Perez" ,20,1.80,57351541,'m',80);
		System.out.println ("Los valores de p1 son: " +p1.toString());
		System.out.println ("Los valores de p2 son: " +p2.toString());
		p2.generarCI();
		System.out.println ("Los valores de p2 son: " +p2.toString());
		if (p2.esMayor())
			System.out.println ("Es mayor de edad");
		else
			System.out.println ("Es menor de edad");
		if (p2.calcularIMC()==1)
			System.out.println ("Sobrepeso");
		else
			if (p2.calcularIMC()==0);
				System.out.println ("Estas por encima de tu peso ideal");
			else
				if (p2.calcularIMC()==0);
				System.out.println ("peso ideal");
	}

}

