Modifique la sangría y, de ser necesario, agregue llaves para producir la siguiente salida:

```
#####
```

```
$$$$$
```

```
&&&&&
```