
class Main {
  public static void main(String[] args) {
    file4 f1=new file4(22,5,2009);
		Articulo m=new Articulo(200,"asd",700,f1);
		Nacional n= new Nacional("montevideo",false,f1,200,"Cuaderno",200);
		Importado i= new Importado(200,2002,100,"fds",200.2,f1);

		System.out.println(m.toString());
		System.out.println(n.toString());
		System.out.println(i.toString());
	}
}
