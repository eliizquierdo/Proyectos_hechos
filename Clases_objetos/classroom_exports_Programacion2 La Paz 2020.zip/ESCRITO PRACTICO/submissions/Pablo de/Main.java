class Main {
  public static void main(String[] args) {
    
		//a
		Vehiculo a=new Vehiculo("brrrr", "lamborgini", 6000);		
		Vehiculo b=new Vehiculo("asdasd", "pininfarina", 47000);
		//b
		System.out.println(b.toString()+"Descuento de patente: "+b.descontarPatente());
		//c
		a.setMarca("mitsubishi");
		//d
		System.out.println("La marca: "+a.getMarca());
		//e
		System.out.println(a.toString()+"Descuento de patente: "+a.descontarPatente());
	}

}
  
