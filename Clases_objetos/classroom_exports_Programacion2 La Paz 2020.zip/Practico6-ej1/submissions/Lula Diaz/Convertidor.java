package ejer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ejercicio1 extends JFrame {

	private JPanel contentPane;
	private JButton btnSalir;
	private JPanel panel;
	private JButton btnConvertir;
	private JButton btnLimpiar;
	private JTextField textKelvin;
	private JTextField textFahrenheit;
	private JTextField textCelsius;
	private JLabel lblCelsius;
	private JLabel lblKelvin;
	private JLabel lblFahrengeit;
	private JLabel lblConvertir;


	public Ejercicio1() {
		iniciarComponentes();
		iniciarManejadoresEventos();
	}
		
		private void iniciarComponentes() {
		// TODO Auto-generated method stub

			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 450, 300);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			btnSalir = new JButton("Salir");
			
			btnSalir.setBounds(314, 228, 89, 23);
			contentPane.add(btnSalir);
			
			panel = new JPanel();
			panel.setBounds(10, 95, 414, 122);
			contentPane.add(panel);
			panel.setLayout(null);
			
			btnConvertir = new JButton("Convertir");
			
			btnConvertir.setBounds(283, 91, 89, 23);
			panel.add(btnConvertir);
			
			textKelvin = new JTextField();
			textKelvin.setColumns(10);
			textKelvin.setBounds(198, 23, 176, 23);
			panel.add(textKelvin);
			
			textFahrenheit = new JTextField();
			textFahrenheit.setColumns(10);
			textFahrenheit.setBounds(198, 57, 176, 23);
			panel.add(textFahrenheit);
			
			lblKelvin = new JLabel("kelvin");
			lblKelvin.setBounds(40, 27, 46, 14);
			panel.add(lblKelvin);
			
			lblFahrengeit = new JLabel("Fahrengeit");
			lblFahrengeit.setBounds(39, 61, 62, 14);
			panel.add(lblFahrengeit);
			
			btnLimpiar = new JButton("Limpiar");
			
			btnLimpiar.setBounds(41, 228, 89, 23);
			contentPane.add(btnLimpiar);
			
			textCelsius = new JTextField();
			textCelsius.setBounds(207, 42, 176, 23);
			contentPane.add(textCelsius);
			textCelsius.setColumns(10);
			
			lblCelsius = new JLabel("Celsius");
			lblCelsius.setBounds(41, 46, 46, 14);
			contentPane.add(lblCelsius);
			
			lblConvertir = new JLabel("Convertit");
			lblConvertir.setBounds(63, 71, 67, 14);
			contentPane.add(lblConvertir);
		}
	

		private void iniciarManejadoresEventos() {
		// TODO Auto-generated method stub
			btnSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					System.exit(0);
				}
			});
			btnLimpiar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					textCelsius.setText(null);
					textKelvin.setText(null);
					textFahrenheit.setText(null);
				}
			});
			btnConvertir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					double resul=Double.valueOf(textCelsius.getText())+273;
					textKelvin.setText(String.valueOf(resul));
					
					double devuelve=Double.valueOf(textCelsius.getText())*1.8+32;
					textFahrenheit.setText(String.valueOf(devuelve));
					
				}
			});
	}

}
