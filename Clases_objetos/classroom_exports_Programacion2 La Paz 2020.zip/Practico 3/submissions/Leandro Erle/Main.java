class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }public class Main {

	public static void main(String[] args) {
	//cree el objeto Articulo
	
    
    Articulo b;
    Fecha f1= new Fecha(12,4,2010);	
    b=new Articulo("azucar",100,40.5,f1);
    Fecha f2= new Fecha(12,5,1990);
    Articulo a = new Articulo ("cocoa",34,56.6,f2); 
    Fecha hoy= new Fecha(18,9,2020);
    if (a.estaVencido(hoy)==true)
    		System.out.println("el articulo esta vencido");
    else
    	System.out.println("el articulo no esta vencido");
    
    System.out.println("El articulo b es:"+b.toString() );
	System.out.println("El articulo a queda: "+a.toString());		
}
	 

}
}