import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    int cantidad=0, edad;
    for (int contador = 0; contador <5; contador++) {
        System.out.println("Ingrese un valor: ");
        edad = entrada.nextInt();
        if (edad>18) {
          cantidad++;
           
        }
    }
    System.out.println("Salida:  " + cantidad + "mayores de 18." );
  }
}