
package logica;

public class Cotizacion {
    private double moneda;
    private final double dolar;
    
    public Cotizacion(){
        dolar = 43.60;
    }

    public Cotizacion(double moneda, double dolar) {
        this.moneda = moneda;
        this.dolar = dolar;
    }

    public double getMoneda() {
        return moneda;
    }

    public void setMoneda(double moneda) {
        this.moneda = moneda;
    }

    public double getDolar() {
        return dolar;
    }

    public double aDolar() {
        return moneda / dolar;
    }
    public double aPeso(){
        return moneda * dolar;
    }
    
    @Override
    public String toString() {
        return "moneda: " + moneda + ", dolar: " + dolar;
    }
    
    
}
