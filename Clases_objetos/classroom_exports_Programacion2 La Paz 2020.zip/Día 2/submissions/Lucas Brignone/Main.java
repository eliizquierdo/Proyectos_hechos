package dia_1;

import dia1.Producto;

public class Main{
	
	public static void main(String[] args){
		Producto a=new Producto();
		Producto b=new Producto("Cloro",50);
		a.setNombre("Hipoclorito");
		a.setPrecio(20);
		
		System.out.println("Nombre es "+a.getNombre());
		System.out.println("Precio: "+a.getPrecio());
		System.out.println("Precio de venta "+a.precioVenta());
		System.out.println("Los datos de b son: "+b.getPrecio());
	}
}