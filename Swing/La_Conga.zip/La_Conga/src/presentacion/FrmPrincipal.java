package presentacion;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import logica.Carta;
import logica.Juego;
import logica.Mazo;


public class FrmPrincipal extends javax.swing.JFrame {
    private Juego game;
    
    public FrmPrincipal() {
        initComponents();
        initJuego();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnIniciar = new javax.swing.JButton();
        btnCarta0 = new javax.swing.JButton();
        btnCarta2 = new javax.swing.JButton();
        btnCarta3 = new javax.swing.JButton();
        btnCarta1 = new javax.swing.JButton();
        btnCarta4 = new javax.swing.JButton();
        btnCarta5 = new javax.swing.JButton();
        btnCarta6 = new javax.swing.JButton();
        btnCarta7 = new javax.swing.JButton();
        btnMazo = new javax.swing.JButton();
        btnMonton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Juego de cartas \"El Burro\"");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnIniciar.setText("Comenzar a jugar");
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        btnCarta0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta0ActionPerformed(evt);
            }
        });

        btnCarta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta2ActionPerformed(evt);
            }
        });

        btnCarta3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta3ActionPerformed(evt);
            }
        });

        btnCarta1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta1ActionPerformed(evt);
            }
        });

        btnCarta4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta4ActionPerformed(evt);
            }
        });

        btnCarta5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta5ActionPerformed(evt);
            }
        });

        btnCarta6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta6ActionPerformed(evt);
            }
        });

        btnCarta7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta7ActionPerformed(evt);
            }
        });

        btnMazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMazoActionPerformed(evt);
            }
        });

        btnMonton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMontonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCarta0, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarta4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCarta5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarta1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCarta2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(btnCarta3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCarta6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCarta7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 198, Short.MAX_VALUE)
                .addComponent(btnMazo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(616, Short.MAX_VALUE)
                    .addComponent(btnMonton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(212, 212, 212)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCarta3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta0, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnCarta6, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta7, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta4, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCarta5, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(btnMazo, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(104, 104, 104)
                    .addComponent(btnMonton, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(231, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//***************************************************************************** 
    private void initJuego() {
        game = new Juego();
        game.iniciarJuego(1);   // Siempre comienza user
        String tapa = "img/otra/tapa.jpg";
        colocarCarta(tapa,btnCarta0);
        colocarCarta(tapa,btnCarta1);
        colocarCarta(tapa,btnCarta2);
        colocarCarta(tapa,btnCarta3);
        colocarCarta(tapa,btnCarta4);
        colocarCarta(tapa,btnCarta5);
        colocarCarta(tapa,btnCarta6);
        colocarCarta(tapa,btnCarta7);
        colocarCarta(tapa,btnMazo);
        btnMazo.setEnabled(false);
        btnMonton.setEnabled(false);
    }
//*****************************************************************************     
    // Dada una ruta y un botón, coloca imagen en el botón
    private void colocarCarta(String ruta,JButton b) {
        b.setIcon(new ImageIcon(ruta));
    }
//*****************************************************************************     
    // Dada una mano de jugador y una posición, obtiene ruta de la posición
    private String obtenerRuta(Mazo j, int i) {
        return j.devolver(i).toString();
    }
//*****************************************************************************     
    // Método que actualiza las imágenes de la carta del jugador.
    private void actualizarImagenes() {
        colocarCarta(obtenerRuta(game.getJugador1(),0),btnCarta0);
        colocarCarta(obtenerRuta(game.getJugador1(),1),btnCarta1);
        colocarCarta(obtenerRuta(game.getJugador1(),2),btnCarta2);
        colocarCarta(obtenerRuta(game.getJugador1(),3),btnCarta3);
        colocarCarta(obtenerRuta(game.getJugador1(),4),btnCarta4);
        colocarCarta(obtenerRuta(game.getJugador1(),5),btnCarta5);
        colocarCarta(obtenerRuta(game.getJugador1(),6),btnCarta6);
        colocarCarta(obtenerRuta(game.getJugador1(),7),btnCarta7);
        System.out.println(game.toString());
    }
//*****************************************************************************    
    // Pasa la carta de todos los jugadores, aplicado la inteligencia
    // Recibe el número del botón (posición de la carta)
    private void jugarMano(int i){
        Carta c1, c2, c3, c4;               // Indica la carta que pasa
       /* 
        c4 = game.inteligencia(game.getJugador4());
        // jugador4 -> jugador1
        c1 = game.pasarCarta(game.getJugador1(),c4,i,true);
        // jugador1 -> jugador2
        c2 = game.pasarCarta(game.getJugador2(),c1,i,false);
        // jugador2 -> jugador3
        c3 = game.pasarCarta(game.getJugador3(),c2,i,false);
        // jugador3 -> jugador4
        c4 = game.pasarCarta(game.getJugador4(),c3,i,false);*/
    }
//*****************************************************************************    
    // Controla si hay ganador. En ese caso reinicia el juego
    private void controlarGanador() {
    /*    if(game.ganador(game.getJugador1())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 1 (¡Usted!)");
            this.initJuego();
        }
        if(game.ganador(game.getJugador2())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 2");
            this.initJuego();
        }   
        if(game.ganador(game.getJugador3())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 3");
            this.initJuego();
        }  
        if(game.ganador(game.getJugador4())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 4");
            this.initJuego();
        }  */
    }
//*****************************************************************************    
    
    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
        actualizarImagenes();   // Envento para inicializar el juego
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void btnCarta0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta0ActionPerformed
        jugarMano(0);           // Paso la carta en la posición 0 (btnCarta0)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta0ActionPerformed

    private void btnCarta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta2ActionPerformed
        jugarMano(2);           // Paso la carta en la posición 2 (btnCarta2)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta2ActionPerformed

    private void btnCarta3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta3ActionPerformed
        jugarMano(3);           // Paso la carta en la posición 3 (btnCarta3)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta3ActionPerformed

    private void btnCarta1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta1ActionPerformed
        jugarMano(1);           // Paso la carta en la posición 1 (btnCarta1)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta1ActionPerformed

    private void btnCarta4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCarta4ActionPerformed

    private void btnCarta5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCarta5ActionPerformed

    private void btnCarta6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCarta6ActionPerformed

    private void btnCarta7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta7ActionPerformed
        game.descartar(game.getResto(),game.getJugador1() ,7);
    }//GEN-LAST:event_btnCarta7ActionPerformed

    private void btnMazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMazoActionPerformed
        game.obtener(game.getCartas(), game.getJugador1(), true);
        
    }//GEN-LAST:event_btnMazoActionPerformed

    private void btnMontonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMontonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMontonActionPerformed
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCarta0;
    private javax.swing.JButton btnCarta1;
    private javax.swing.JButton btnCarta2;
    private javax.swing.JButton btnCarta3;
    private javax.swing.JButton btnCarta4;
    private javax.swing.JButton btnCarta5;
    private javax.swing.JButton btnCarta6;
    private javax.swing.JButton btnCarta7;
    private javax.swing.JButton btnIniciar;
    private javax.swing.JButton btnMazo;
    private javax.swing.JButton btnMonton;
    // End of variables declaration//GEN-END:variables
}