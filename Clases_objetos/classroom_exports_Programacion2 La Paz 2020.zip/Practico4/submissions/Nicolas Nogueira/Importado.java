public class Importado extends Articulo {
	private int anioImportacion;
	private double impuestos;
	
	
	public Importado() {
		super();
	}


	public Importado(double imp,int aImp,int codigo, String nombre, double precioCosto, file4 naci) {
		super(codigo, nombre, precioCosto, naci);
		imp=impuestos;
		aImp=anioImportacion;
		
		
	}


	public int getAnioImportacion() {
		return anioImportacion;
	}


	public void setAnioImportacion(int anioImportacion) {
		this.anioImportacion = anioImportacion;
	}


	public double getImpuestos() {
		return impuestos;
	}


	public void setImpuestos(double impuestos) {
		this.impuestos = impuestos;
	}
	
	public double precioVenta() {
		double monto=super.precioVenta();
		if(anioImportacion<=2008){
			return (monto + impuestos*0.80);
		}
		else
			return impuestos;
		
	}


	@Override
	public String toString() {
		return super.toString()+"Año imporacion"+ anioImportacion+"Impuestos: "+ impuestos+ precioVenta(); 
	}

	

}