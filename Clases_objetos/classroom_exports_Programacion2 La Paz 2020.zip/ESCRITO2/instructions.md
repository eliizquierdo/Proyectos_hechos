 

**Ejercicio 1        (6 puntos)**

 Dada la clase Vehiculo que permita guardar: la **marca**, el **precio** y la **matricula**.

1. Agregar a la clase el atributo **fechaCompra** de tipo Fecha (también dada),
2. Modificar todo lo necesario para que funcione correctamente.
3. Agregar el método especifico _descuentoNeto(): double_, tal que si el año de la fecha de compra es menor del 2010 tiene un 20% de descuento sobre el precio
4. En la clase Main,  instancie y muestre los datos de 2 vehiculos.
5. Pruebe el método _descuentoNeto()_ en la clase Main

**Ejercicio 2      (6 puntos)** 

6. Crear la clase Moto que herede de Vehiculo, con el atributo **cilindrada** de int
7. Agregar todos los métodos básicos de la clase
8. En la clase **Main**, instancie y muestre los datos de 2 motos.
9. En la clase Moto, sobreescriba el método descuentoNeto de la clase Vehiculo, teniendo en cuenta que si la cilindrada es menor a 100 tendrá un 10% de descuento adicional
10. Pruebe el método _descuentoNeto()_ de la clase Moto en la clase Main.