public class Producto {

	private String Nombre;
	private double Precio;
	
	
	public Producto() {
		
		
	}
	
	
	public Producto(String nombre, double precio) {
		super();
		Nombre = nombre;
		Precio = precio;
	}


	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public double getPrecio() {
		return Precio;
	}
	public void setPrecio(double precio) {
		Precio = precio;
	}
	
	public double precioVenta() {
		double precioVenta=200;
		if (Precio<50)
			precioVenta=100;
		return precioVenta;
	}
	
	@Override
	public String toString() {
		return "Producto [Nombre=" + Nombre + ", Precio=" + Precio + "]";
	}
	
	
	
	
	
}
