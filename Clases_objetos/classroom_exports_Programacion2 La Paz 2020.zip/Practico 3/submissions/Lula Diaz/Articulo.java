package ejer2;
import java.util.Scanner;
import ejer1.Fecha1;

public class Articulo1 {
		
	private int codigo;
	private String nombre;
	private double precioCosto;
	private Fecha1 vencimiento;
		
	public Articulo1() {
			
	}
		
	public Articulo1(int codigo, String nombre, double precioCosto, Fecha1 f) {
			this.codigo = codigo;
			this.nombre = nombre;
			this.precioCosto = precioCosto;
			this.vencimiento = f;
			
	}
		
		

	public Fecha1 getNacimiento() {
		return vencimiento;
	}

	public void setNacimiento(Fecha1 nacimiento) {
		this.vencimiento = nacimiento;
	}

	public int getCodigo() {
			return codigo;
	}

	public void setCodigo(int codigo) {
			this.codigo = codigo;
	}

	public String getNombre() {
			return nombre;
	}

	public void setNombre(String nombre) {
			this.nombre = nombre;
	}

	public double getPrecioCosto() {
			return precioCosto;
	}

	public void setPrecioCosto(double precioCosto) {
			this.precioCosto = precioCosto;
	}
		
	/////////////////////////////////////////////
	
	public boolean  estaVencido(Fecha1 f){
		boolean esta = false; 
		
		if ((f.getMes() - vencimiento.getMes())> 6)
			esta = true;
	
		return esta;
	}
	
	

		public double precioVenta() {
			double precioVenta;
			precioVenta = precioCosto + (precioCosto*20/100);
			return precioVenta;
		}
		
		public void pedirDatos() {
			Scanner tecla = new Scanner(System.in);
			
			System.out.println("Ingrese codigo: ");
			setCodigo(tecla.nextInt());
			System.out.println("Ingrese nombre: ");
			setNombre(tecla.next());
			System.out.println("Ingrese precio de compra: ");
			setPrecioCosto(tecla.nextDouble());
		}
		
		public String toString() {
			return "Codigo: " + codigo + "\nNombre: " + nombre + "\nPrecio de venta + nacimiento.toString(): " + precioVenta();
		}
}
