package controlador;

import modelo.dao.*;
import modelo.vo.*;

public class Principal {
	public static void main(String[] args){
		String resp;
		Persona p=new Persona();
		Persona p2=new Persona();
		
		/***prueba insertar en la BD***/
		p.pedirDatos();		
		PersonaDAO per=new PersonaDAO();
		
		resp=per.insertarPersona(p);
		if (resp!=null)
				System.out.println("Registro exitoso");
		
		/***prueba eliminar en la BD***/
		int res=per.eliminarPersona(5);
		if (res==1)
			System.out.println("Registro eliminado correctamente");
		
		/***prueba actualizar en la BD***/
		p.setApellido("Perez");
		resp=per.actualizarPersona(p);
		if (res==1)
			System.out.println("Registro actualizado correctamente");
		System.out.println("Ver los datos actualizados en la BD ");
		
		/***prueba listar la BD***/		
		System.out.println(per.listarPersonas());
		
		/***prueba buscar x cédula en la BD***/	
		System.out.println("Cédula a buscar: 1 ");
		p2=per.buscarXCedula(1);
		if (p2!=null)
			System.out.println("Los datos para cedula encontrados son: "+p2.toString());
		else
			System.out.println("La persona no se encuentra");
	}
}
