class Main {
  public static void main(String[] args) {
}
	  Vehiculo a1=new Vehiculo();
	Vehiculo a2=new Vehiculo("Fiat",12000,2013);
	System.out.println("a1 tiene:-> \n"+a1.toString());
	System.out.println("\na2 tiene:-> \n"+a2.toString());
	System.out.println("La marca de a2 es: "+a2.getMarca());	
	a2.setMarca("Ford");
	System.out.println("La marca de a2 es: "+a2.getMarca());	
	a1.setMarca("Honda");
	a1.setPrecio(12000);
	a1.setAnio(2013);
	System.out.println("a1 tiene-> \n"+a1.toString());
	double DescuentoPatente=a1.patente();
	System.out.println("La patente de a1 es:"+DescuentoPatente);
	
	
	
	}

}
