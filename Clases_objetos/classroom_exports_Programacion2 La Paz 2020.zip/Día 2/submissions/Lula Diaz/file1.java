public class file_1 {

private String Nombre;
private double Precio;
private file_3 FechaVencimiento;


public file_1() {
}
public file_1(String nombre, double precio, file_3 FechaNacimiento) {
super();
this.Nombre = nombre;
this.Precio = precio;
this.FechaVencimiento = FechaNacimiento;
}


public file_3 getFechaVencimiento() {
return FechaVencimiento;
}


public void setFechaVencimiento(file_3 fechaVencimiento) {
FechaVencimiento = fechaVencimiento;
}


public String getNombre() {
return Nombre;
}
public void setNombre(String nombre) {
Nombre = nombre;
}
public double getPrecio() {
return Precio;
}
public void setPrecio(double precio) {
Precio = precio;
}
public double precioVenta() {
double precioVenta=200;
if (Precio<50)
precioVenta=100;
return precioVenta;
}
@Override
public String toString() {
return "Producto [Nombre=" + Nombre + ", Precio=" + Precio + ", FechaVencimiento=" + FechaVencimiento + "]";
}
}