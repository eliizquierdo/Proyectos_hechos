  

**Ejercicio 1** **(5 puntos)**

 
 

Dada una clase llamada **Vehiculo** que permita guardar: la _matrícula_ y _marca_ (de tipo String) y el _precio_ (de tipo double). Escriba la clase con todos los atributos, el constructor completo, los métodos getters, setters y toString.

 
 

**Ejercicio 2** **(2 puntos)**

 
 

Realizar el método **descontarPatente():double** tal que si el precio es >10000 el descuento sea de un 10% del precio

 
 

**Ejercicio 3 (5 puntos)**

 En la clase Main:

a)  Crear dos Vehiculos con el constructor especifico

b) Mostrar en pantalla todos los datos de uno de los Vehiculos.

c) Modificar algún dato de los vehiculos creados.

d) Mostrar en pantalla que el cambio anterior  quedo hecho.

e) Probar el método **descontarPatente** 