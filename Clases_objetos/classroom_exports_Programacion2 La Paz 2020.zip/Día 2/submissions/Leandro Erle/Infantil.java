public class Infantil extends Libro {
	
	
private String editorial;
	

public Infantil() {
		
}


public Infantil(String tit, int cant, String aut,String edi,Fecha crea) {
	super(tit, cant, aut,crea);
	this.editorial = edi;
}


public String getEditorial() {
	return editorial;
}


public void setEditorial(String editorial) {
	this.editorial = editorial;
}








@Override
public String toString() {
	return super.toString() + "Infantil [paginas=" + editorial + "]";
}


	






}





