
public class Calculadora {

	int suma(int a, int b){
	  return(a+b);
	}
	int resta(int a, int b){
	  return(a-b);
	}
	int multiplica(int a, int b){
	  return(a*b);
	}
	int divide(int a, int b){
	  if (b==0){
	    return (-1);
	  }else{
	  return(a/b);
	  }
	}
	int resto(int a, int b){
	  if (b==0){
	    return(-1);
	  }else{
	    return(a%b);
	  }
	}
	  
	  
	  
	}