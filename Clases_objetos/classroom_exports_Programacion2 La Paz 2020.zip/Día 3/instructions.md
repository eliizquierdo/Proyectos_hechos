Crear una clase que tenga como atributo un ArrayList de la clase que hayas hecho el Día1, crear el constructor y los métodos básicos (insertar, eliminar, obtener, pertenece y cantidad)

Probar todos los métodos en la clase Main