public class Fecha{
	private int dia;
	private int mes;
	private int año;

  
  public Fecha(){
	  
  }
  public Fecha(int d, int m, int a){
	  dia= d;
	  mes= m;
	  año= a;
  }
  public int getDia(){
	  return dia;
  }
  
  public int getMes(){
	  return mes;
  }
  public int getAño(){
	  return año;
  }
  public void setDia(int d){
	  this.dia =d;
  }
  public void setMes(int m){
	  this.mes =m;
  }
  public void setAño(int a){
	  this.año =a;
  }
  
  public String toString(){
	  return dia +"/" + mes + "/" + año;
  }
  
}