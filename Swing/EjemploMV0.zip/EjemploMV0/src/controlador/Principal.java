package controlador;
//En esta versi�n  se utiliza una coleccion static

import vista.*;

public class Principal {
	public static void main(String[] args){
		MenuPrincipal mp=new MenuPrincipal();
		mp.setVisible(true);
		
	}
}
