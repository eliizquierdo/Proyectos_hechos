import java.util.Scanner;

class Main {
  
  public static void main(String[] args) {
    Scanner entrada=new Scanner(System.in);
    int cantAsteriscos;
    
    /******************  Ejemplo ***************************/
    for (int contador = 1; contador <= 5; contador++) {
      System.out.println(" * ");
    } 
    System.out.println("Parte 1");
   /************** Agregar codigo AQUÍ ***************/
    for (int contador = 1; contador <= 10; contador++) {
      System.out.print(" * ");
    } 
    
    /******************************************************/
    System.out.println("Parte 2");
    System.out.println("Ingrese cuantos * quiere imprimir: ");
    cantAsteriscos=entrada.nextInt();
    /************** Agregar codigo AQUÍ ***************/
    for (int i=0; i< cantAsteriscos; i++){
      System.out.print(" * ");
    }
    
    /******************************************************/
    System.out.println("Parte 3");
   /************** Agregar codigo AQUÍ ***************/
     for (int i=1; i<= cantAsteriscos; i++){
      System.out.println(i);
    }
    
    /******************************************************/
     System.out.println("Parte 4");
   /************** Agregar codigo AQUÍ ***************/
       for (int i=0; i<= cantAsteriscos; i++){
          if (i%2==0) {
      System.out.println(i);
          }
    }
    
    /******************************************************/
    
    System.out.println("Fin de la ejecución.");
  }
}