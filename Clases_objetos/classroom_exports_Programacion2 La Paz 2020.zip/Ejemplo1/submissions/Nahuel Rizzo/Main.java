import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Hola Mundo!");
    
   
      String nom;
	    int edad;
	  
	    nom="0";
	    edad=0;
	  
	    Scanner tecla=new Scanner(System.in);
	    System.out.print("Ingrese su nombre: ");
	    nom=tecla.nextLine();
	    System.out.print("Ingrese su edad: ");
	    edad=tecla.nextInt();
	    System.out.print("Su nombre es "+nom);
	    System.out.print(" y su edad es "+edad);
  }
}