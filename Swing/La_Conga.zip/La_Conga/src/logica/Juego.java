package logica;

public class Juego {

    private Mazo cartas;        // Todas las cartas
    private Mazo jugador1;
    private Mazo jugador2;
    private Mazo jugador3;
    private Mazo jugador4;
    private Mazo resto;        // Las cartas boca arriba para elegir

    public Juego() {
        cartas = new Mazo();
        jugador1 = new Mazo(); // Cartas de jugador1 = 0
        jugador2 = new Mazo(); // Cartas de jugador2 = 0
        jugador3 = new Mazo(); // Cartas de jugador3 = 0
        jugador4 = new Mazo(); // Cartas de jugador4 = 0
        resto = new Mazo();
        cartas.armarMazo();    // Cartas de mazo = 48 
    }
    // Getters de todos los jugadores
    public Mazo getJugador1() {
        return jugador1;
    }
    public Mazo getJugador2() {
        return jugador2;
    }
    public Mazo getJugador3() {
        return jugador3;
    }
    public Mazo getJugador4() {
        return jugador4;
    }
    public Mazo getCartas() {
        return cartas;
    }
    public Mazo getResto() {
        return resto;
    }    
//****************************************************************************    
    /**
     * iniciarJuego: Reparte 7 cartas a cada jugador + 1 al jugador del turno
     */
    public void iniciarJuego(int turno) {
        for (int i = 0; i < 7; i++) {
            jugador1.insertar(cartas.darCarta());
            jugador2.insertar(cartas.darCarta());
            jugador3.insertar(cartas.darCarta());
            jugador4.insertar(cartas.darCarta());
        }
        switch (turno) {
            case 1: // turno jugador 1
                jugador1.insertar(cartas.darCarta());
                break;
            case 2: // turno jugador 2
                jugador1.insertar(cartas.darCarta());
                break;    
            case 3: // turno jugador 3
                jugador1.insertar(cartas.darCarta());
                break;
            case 4: // turno jugador 4
                jugador1.insertar(cartas.darCarta());
                break;
        } 
    }
//****************************************************************************
    public Carta descartar(Mazo r, Mazo j, int i) {
        Carta c = j.devolver(i);   // Obtengo la carta que quiero descartar
        r.insertar(c);             // La coloco en el resto de cartas
        j.eliminar(i);             // La elimino de j
        return c;
    }
//****************************************************************************
    public void obtener(Mazo m, Mazo j, boolean lugarMazo) {
        if (lugarMazo)           // Si la obtengo del mazo boca abajo
            j.insertar(m.darCarta());
        else                    // si-no la obtengo del resto boca arriba
            j.insertar(m.devolver(0));
    }
    
//****************************************************************************
    /**
     * pasarCartas: Método para simular una pasada de cartas
     * @param jug un jugador
     * @param c la carta que recibe
     * @param i la carta que devuelve (si es el usuario)
     * @param user si es el usuario o no
     * @return devolver = la carta que devuelve
     */
/*    public Carta pasarCarta(Mazo jug, Carta c, int i, boolean user) {
        Carta devuelve;
        if (user == true) {             // Si es el usuario
            devuelve = jug.devolver(i);
            jug.eliminar(i);
        } else {                        // Si es la maquina
            devuelve = this.inteligencia(jug);
            jug.eliminar(this.inteligencia(jug));
        }
        jug.insertar(c);                  // Se queda con una carta
        return devuelve;                // Devuelve una carta
    }*/
//*****************************************************************************    
    /**
     * ganador: Determina si un jugador gano la partida
     * @param jug un jugador
     * @return true si todas sus cartas son iguales
     */
 /*   public boolean ganador(Mazo jug) {
        boolean gano = true;
        // Obtengo la primer carta del jugador ....
        Carta c = jug.devolver(0);
        // ... la comparo con las otras tres
        for (int i = 1; i < jug.cantidad(); i++) {
            if (c.getNumero() != jug.devolver(i).getNumero()) {
                gano = false; // Si hay una distinta entonces false
            }
        }
        return gano;
    }*/
//*****************************************************************************    
     /**
     * cantidadNumeroCartas: Cuenta la cantidad de 1, 10, 11 y 12 del jugador
     * @param jug un jugador
     * @return un array con la estadistica del conteo.
     */
  /*  int[] cantidadNumeroCartas(Mazo jug) {
        int[] contar = new int[4];
        // Recorre la mano del jugador
        for (int i = 0; i < jug.cantidad(); i++) {
            // Obtiene el número de la carta
            switch (jug.devolver(i).getNumero()) {
                case 1:                 // Contador de as (posicion 0)
                    contar[0]++;
                    break;
                case 10:                // Contador de sota (posicion 1)
                    contar[1]++;
                    break;
                case 11:                // Contador de caballo (posicion 2)
                    contar[2]++;
                    break;
                case 12:                // Contador de rey (posicion 3)
                    contar[3]++;
            }
        }
        return contar;
    }   */
//*****************************************************************************
    /**
     * asociarContador: Controlador para devolver la carta exacta
     * @param jug un jugador
     * @param posContador asocia 0 (as), 1 (sota), 2 (caballo), 3 (rey)
     * @param posCarta posición de la carta del jugador
     * @return true si hay relación entre posContador y posCarta
     */
/*    public boolean asociarContador(Mazo jug, int posContador, int posCarta) {
        boolean cumple = false;
        if (posContador == 0 && jug.devolver(posCarta).getNumero() == 1) {
            cumple = true;
        } else if (posContador==1 && jug.devolver(posCarta).getNumero()==10) {
            cumple =  true;
        } else if (posContador==2 && jug.devolver(posCarta).getNumero()==11) {
            cumple =  true;
        } else if (posContador==3 && jug.devolver(posCarta).getNumero()==12) {
            cumple =  true;
        }
        return cumple;
    }*/
//*****************************************************************************
    /**
     * inteligencia: La "IA" de la computadora
     * Utiliza cantidadNumeroCartas y asociarContador
     * @param jug un jugador
     * @return la carta que menos le sirve
     */
 /*   public Carta inteligencia(Mazo jug) {
        Carta auxiliar = new Carta();
        boolean seguir = true;
        int posContador = 0;           // Para posicion del contador    
        int posCarta = 0;              // Para posicion de cartas de j
        // Contador de cartas
        int[] contador = this.cantidadNumeroCartas(jug);
        // Caso general: todas distintas [1][1][1][1]
        // Caso general: tres iguales [0][1][0][3]
        // Caso general: dos iguales [0][1][2][1]
        // Devuelve la primer carta con contador 1.
        while (posContador < contador.length && seguir == true) {
            if (contador[posContador] == 1) {
                for (posCarta = 0; posCarta < jug.cantidad(); posCarta++) {
                    if (this.asociarContador(jug,posContador,posCarta) == true)
                        auxiliar = jug.devolver(posCarta);
                }
                seguir = false;
            }
            posContador++;
        }
        if (seguir == true) { // Termina while y no hay contadores con 1
            // Caso particular: Pares iguales [0][2][0][2]
            // Devuelve la última carta con contador 2
            for (posContador = 0; posContador < contador.length; posContador++) {
                if (contador[posContador] == 2) {
                    if (this.asociarContador(jug,posContador,posCarta) == true)
                        auxiliar = jug.devolver(posCarta);
                }
            }
        }
        return auxiliar;
    }*/
//*****************************************************************************
    @Override
    public String toString() {
        return "\n\n\nNueva jugada: "
                + "\nmazo: " + cartas.cantidad()
                + "\nmazo: " + resto.cantidad()
                + "\njugador1: " + jugador1
                + "\njugador2:" + jugador2
                + "\njugador3: " + jugador3
                + "\njugador4:" + jugador4;
    }
//*****************************************************************************    
} // "Fin del Juego"
