class Main {
    static void main(String[] args) {
		// TODO Auto-generated method stub
		Libro b;	
	    b=new Libro("azucar",100,"Lucas alias el rengo");
	    
	    Libro a = new Libro ("cocoa",34,"Karateca Javier"); 
	   System.out.println(b.toString());
	   System.out.println("El titulo de b es:"+ b.getTitulo());
	   System.out.println("a es: "+ a.precioVenta());
	}

}

  