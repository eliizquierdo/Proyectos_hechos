package Ejercicio2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Ejercicio2 {

	private JFrame frame;
	private JButton btnSalir;
	private JButton btnLimpiar;
	private JLabel lblIngrese;
	private JTextField txtNumero;
	private JButton btnIncrementar;
	private JButton btnSigno;
	private JButton btnCuadrado;
	private JLabel lblNewLabel;
	private JPanel panel;


	/**
	 * @wbp.parser.entryPoint
	 */
	public Ejercicio2() {
		IniciarComponentes();
		IniciarManejadorDeEventos();
	}


	private void IniciarComponentes() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		panel = new JPanel();
		panel.setBounds(23, 11, 389, 190);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(27, 47, 80, 14);
		panel.add(lblNewLabel);
		
		lblIngrese = new JLabel("Ingrese n\u00FAmero:");
		lblIngrese.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngrese.setBounds(10, 44, 113, 14);
		panel.add(lblIngrese);
		
		txtNumero = new JTextField();
		txtNumero.setBounds(133, 41, 204, 20);
		panel.add(txtNumero);
		txtNumero.setColumns(10);
		
		btnIncrementar = new JButton("Incrementar");
		
		btnIncrementar.setBounds(27, 144, 102, 23);
		panel.add(btnIncrementar);
		
		btnSigno = new JButton("Signo");
		btnSigno.setBounds(153, 144, 89, 23);
		panel.add(btnSigno);
		
		btnCuadrado = new JButton("Cuadrado");
		btnCuadrado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCuadrado.setBounds(272, 144, 89, 23);
		panel.add(btnCuadrado);

		btnSalir = new JButton("Salir");
		btnSalir.setBounds(323, 227, 89, 23);
		frame.getContentPane().add(btnSalir);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.setBounds(23, 227, 89, 23);
		frame.getContentPane().add(btnLimpiar);
	}

	private void IniciarManejadorDeEventos() {
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		// cuadrado
		btnCuadrado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		//incrementar
		btnIncrementar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		//signo

	}
}
