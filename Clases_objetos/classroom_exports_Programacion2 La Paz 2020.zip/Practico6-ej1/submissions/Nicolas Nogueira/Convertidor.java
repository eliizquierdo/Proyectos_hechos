

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import java.awt.Color;

public class Convertidor extends JFrame {
	private JTextField txtCelsius;
	private JTextField txtKelvin;
	private JTextField txtFahrenheit;
	JButton btnSalir;
	JButton btnConvertir;
	JButton btnLimpiar;
	
	public Convertidor() {
		iniciarComponentes();
		iniciarManejadoresEventos();
	}
	
	public void iniciarComponentes() {
		setTitle("Temperaturas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 394, 300);
		getContentPane().setLayout(null);
		
		txtCelsius = new JTextField();
		txtCelsius.setBounds(136, 37, 217, 23);
		getContentPane().add(txtCelsius);
		txtCelsius.setColumns(10);
		
		btnSalir = new JButton("Salir");
		
		btnSalir.setBounds(264, 228, 89, 23);
		getContentPane().add(btnSalir);
		
		btnLimpiar = new JButton("Limpiar");
		
		btnLimpiar.setBounds(10, 228, 89, 23);
		getContentPane().add(btnLimpiar);
		
		JLabel lblCelsius = new JLabel("Celsius");
		lblCelsius.setBounds(10, 37, 116, 23);
		getContentPane().add(lblCelsius);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Convertir", TitledBorder.LEADING, TitledBorder.TOP, null, Color.GRAY));
		panel.setBounds(10, 68, 347, 141);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblKelvin = new JLabel("Kelvin");
		lblKelvin.setBounds(10, 27, 72, 14);
		panel.add(lblKelvin);
		
		txtKelvin = new JTextField();
		txtKelvin.setEditable(false);
		txtKelvin.setBounds(132, 24, 203, 20);
		txtKelvin.setColumns(10);
		panel.add(txtKelvin);
		
		JLabel lblFahrenheit = new JLabel(" Fahrenheit");
		lblFahrenheit.setBounds(10, 58, 142, 23);
		panel.add(lblFahrenheit);
		
		txtFahrenheit = new JTextField();
		txtFahrenheit.setEditable(false);
		txtFahrenheit.setColumns(10);
		txtFahrenheit.setBounds(132, 58, 203, 23);
		panel.add(txtFahrenheit);
		
		btnConvertir = new JButton("Convertir");
		btnConvertir.setBounds(241, 107, 89, 23);
		panel.add(btnConvertir);
	}	
	
	public void iniciarManejadoresEventos(){
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtKelvin.setText("");
				txtFahrenheit.setText("");
					
			}
		});
	
		btnConvertir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
						double celsius=Double.valueOf(txtCelsius.getText());
						txtKelvin.setText(String.valueOf(Math.round(celsius+273.15)));
						txtFahrenheit.setText(String.valueOf(Math.round(celsius*1.8+32)));
					
						
					}catch(Exception ex){
						JOptionPane.showMessageDialog(null," Un tropezon no es caida :)");
					}
				}
			
		});
	}	
		
	
}