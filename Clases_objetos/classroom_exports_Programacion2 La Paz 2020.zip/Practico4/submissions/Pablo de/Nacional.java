public class Nacional extends Articulo{
	private String departamento;
	private boolean subsidiado;
	
	public Nacional(String dep,boolean subsi,file4 naci, int codigo, String nombre, double precioCosto) {
		super(codigo, nombre, precioCosto, naci);
		subsi=subsidiado;
		dep=departamento;
		
	}
	public Nacional() {
		super();
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public boolean isSubsidiado() {
		return subsidiado;
	}
	public void setSubsidiado(boolean subsidiado) {
		this.subsidiado = subsidiado;
	}
	@Override
	public double precioVenta() {
	double monto=super.precioVenta();
		if(subsidiado){
			return monto;
		}
			else if(departamento.equals("montevideo")){
					return(monto*1.15);
					
				}
			else{
				return(monto*1.10);
			}
			
		}
		 
		
	@Override
	public String toString() {
		return super.toString()+ "Departamento: "+departamento +" subsidiado: " + subsidiado;
	}

}