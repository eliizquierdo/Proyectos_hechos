

public class Main{
public static void main(String[] args){
file_1 a=new file_1();
a.setNombre("Yerba");
a.setPrecio(20);
System.out.println("Nombre es "+a.getNombre());
System.out.println("Precio: "+a.getPrecio());
System.out.println("Precio de venta "+a.precioVenta());

}
}