class Main {
  
  public static void main(String[] args) {
    
    Calculadora p=new Calculadora();
    int result1= p.suma(2,3);
    System.out.println("El resultado de la suma es: "+result1);
    int result2= p.resta(6,9);
    System.out.println("El resultado de la resta es: "+result2);
    int result3= p.multiplica(3,5);
    System.out.println("El resultado de la multiplicacion es: "+result3);
    int result4= p.divide(12,6);
    System.out.println("El resultado de la division es: "+result4);
    float result5= p.resto(20,3);
    System.out.println("El resultado del resto es: "+result5);
    
  }
}