package presentacion;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import logica.Carta;
import logica.Juego;
import logica.Mazo;


public class FrmPrincipal extends javax.swing.JFrame {
    private Juego game;
    
    public FrmPrincipal() {
        initComponents();
        initJuego();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnIniciar = new javax.swing.JButton();
        btnCarta0 = new javax.swing.JButton();
        btnCarta2 = new javax.swing.JButton();
        btnCarta3 = new javax.swing.JButton();
        btnCarta1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Juego de cartas \"El Burro\"");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnIniciar.setText("Comenzar a jugar");
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        btnCarta0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta0ActionPerformed(evt);
            }
        });

        btnCarta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta2ActionPerformed(evt);
            }
        });

        btnCarta3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta3ActionPerformed(evt);
            }
        });

        btnCarta1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarta1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnCarta0, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCarta1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCarta2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCarta3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(372, 372, 372)
                        .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCarta2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarta1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarta0, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCarta3, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//***************************************************************************** 
    private void initJuego() {
        game = new Juego();
        game.iniciarJuego();
        String tapa = "img/otra/tapa.png";
        colocarCarta(tapa,btnCarta0);
        colocarCarta(tapa,btnCarta1);
        colocarCarta(tapa,btnCarta2);
        colocarCarta(tapa,btnCarta3);
    }
//*****************************************************************************     
    // Dada una ruta y un botón, coloca imagen en el botón
    private void colocarCarta(String ruta,JButton b) {
        b.setIcon(new ImageIcon(ruta));
    }
//*****************************************************************************     
    // Dada una mano de jugador y una posición, obtiene ruta de la posición
    private String obtenerRuta(Mazo j, int i) {
        return j.devolver(i).toString();
    }
//*****************************************************************************     
    // Método que actualiza las imágenes de la carta del jugador.
    private void actualizarImagenes() {
        colocarCarta(obtenerRuta(game.getJugador1(),0),btnCarta0);
        colocarCarta(obtenerRuta(game.getJugador1(),1),btnCarta1);
        colocarCarta(obtenerRuta(game.getJugador1(),2),btnCarta2);
        colocarCarta(obtenerRuta(game.getJugador1(),3),btnCarta3);
        System.out.println(game.toString());
    }
//*****************************************************************************    
    // Pasa la carta de todos los jugadores, aplicado la inteligencia
    // Recibe el número del botón (posición de la carta)
    private void jugarMano(int i){
        Carta c1, c2, c3, c4;               // Indica la carta que pasa
        
        c4 = game.inteligencia(game.getJugador4());
        // jugador4 -> jugador1
        c1 = game.pasarCarta(game.getJugador1(),c4,i,true);
        // jugador1 -> jugador2
        c2 = game.pasarCarta(game.getJugador2(),c1,i,false);
        // jugador2 -> jugador3
        c3 = game.pasarCarta(game.getJugador3(),c2,i,false);
        // jugador3 -> jugador4
        c4 = game.pasarCarta(game.getJugador4(),c3,i,false);
    }
//*****************************************************************************    
    // Controla si hay ganador. En ese caso reinicia el juego
    private void controlarGanador() {
        if(game.ganador(game.getJugador1())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 1 (¡Usted!)");
            this.initJuego();
        }
        if(game.ganador(game.getJugador2())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 2");
            this.initJuego();
        }   
        if(game.ganador(game.getJugador3())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 3");
            this.initJuego();
        }  
        if(game.ganador(game.getJugador4())) {
            JOptionPane.showMessageDialog(null, "Gana Jugador 4");
            this.initJuego();
        }  
    }
//*****************************************************************************    
    
    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
        actualizarImagenes();   // Envento para inicializar el juego
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void btnCarta0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta0ActionPerformed
        jugarMano(0);           // Paso la carta en la posición 0 (btnCarta0)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta0ActionPerformed

    private void btnCarta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta2ActionPerformed
        jugarMano(2);           // Paso la carta en la posición 2 (btnCarta2)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta2ActionPerformed

    private void btnCarta3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta3ActionPerformed
        jugarMano(3);           // Paso la carta en la posición 3 (btnCarta3)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta3ActionPerformed

    private void btnCarta1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarta1ActionPerformed
        jugarMano(1);           // Paso la carta en la posición 1 (btnCarta1)
        actualizarImagenes();   // Actualiza imagenes y toString de jugadores
        controlarGanador();     // Si hay un ganador reinicia el juego
    }//GEN-LAST:event_btnCarta1ActionPerformed
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCarta0;
    private javax.swing.JButton btnCarta1;
    private javax.swing.JButton btnCarta2;
    private javax.swing.JButton btnCarta3;
    private javax.swing.JButton btnIniciar;
    // End of variables declaration//GEN-END:variables
}