public class Articulo {
	private int codigo;
	private String nombre;
	private double precioCosto;
	
	public Articulo(int codigo, String nombre, double precioCosto) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precioCosto = precioCosto;
	}


	public double precioVenta(){
		return precioCosto*0.2;
		
	}
	

}