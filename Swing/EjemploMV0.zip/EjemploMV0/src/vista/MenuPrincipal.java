package vista;

import javax.swing.*;
import modelo.vo.*;

import java.awt.*;
import java.awt.event.*;

public class MenuPrincipal extends JFrame  implements ActionListener{
	
	//creaci�n de la colecci�n de Personas
	public static ListaPersonas coleccion = new ListaPersonas();
    
	//lo �nico que contendr� este JFrame ser� la barra de men�
	
	//**************************************************		
	private JMenuBar mnbPrincipal = new JMenuBar(); //Barra de menus
	//**************************************************
	
	//menu 
	private  JMenu jMenuPersonas;
    
	// opciones del menu Personas
    private JMenuItem itemAlta;
    private JMenuItem itemBuscar;
    private JMenuItem itemVer;

    
   
    //constructor
    public MenuPrincipal() {        
    	setTitle("Menu Principal Personas");
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setResizable(false);
    	this.setBounds(200, 50,600,500);
        iniciarComponentes();
      
                     
    }
    
    private void iniciarComponentes() {
    	    	
    	//barra de men� principal
    	mnbPrincipal = new JMenuBar();
    	
    	//Men� Personas
        jMenuPersonas = new  JMenu("Personas");
               
        //opciones de men� Personas
        itemAlta = new  JMenuItem("Agregar Persona");
        itemAlta.addActionListener(this);
        
        itemBuscar = new  JMenuItem("Buscar Persona");
        itemBuscar.addActionListener(this);
        
        itemVer= new  JMenuItem("Ver Personas");
        itemVer.addActionListener(this);
        
        //agregamos los itemMen�  al men�
        jMenuPersonas.add(itemAlta);
        jMenuPersonas.add(itemBuscar);
        jMenuPersonas.add(itemVer);
        
        //agregamos el men� Alumnos a la barra de men�
        mnbPrincipal.add(jMenuPersonas);
        
        //colocamos el men� principal en el JFrame
        setJMenuBar(mnbPrincipal);
       
        
    }

   
       
    @Override
	public void actionPerformed(ActionEvent e) {
    	if (e.getSource()==itemAlta){
    		
    		AgregarPersona altaPer = new AgregarPersona(); 
    		altaPer.setVisible(true);
    	}
    	if (e.getSource()==itemBuscar){
			
    		BuscarPersona busPer = new BuscarPersona(); 
    		busPer.setVisible(true);
    	}
    	if (e.getSource()==itemVer){
    		
			VerPersonasTabla tablaPer = new VerPersonasTabla(); 
			tablaPer.setVisible(true);
    		
    		
    	}
	  	
    }
    
   
    public static void main(String args[]) {
    	
    	MenuPrincipal m=new MenuPrincipal();
    	m.setVisible(true);
    }

}
