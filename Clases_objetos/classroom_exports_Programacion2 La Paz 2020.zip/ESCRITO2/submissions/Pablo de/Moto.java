
public class Moto extends Vehiculo{
	private int cilindrada;

	public Moto() {
		super();
	}

	public Moto(int cilindrada, String marca, double precio, String matricula, Fecha fechaCompra) {
		super(marca, precio, matricula, fechaCompra);
		this.cilindrada=cilindrada;

	}

	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}

	@Override
	public String toString() {
		return super.toString()+" Moto [cilindrada=" + cilindrada + "]";
	}
	
	
	
	
	
	

}