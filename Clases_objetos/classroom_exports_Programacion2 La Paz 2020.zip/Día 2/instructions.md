Pegue aquí su código, la clase realizada el Día 1 con el atributo agregado, la clase que usó para realizar la agregación y una clase que herede de la clase realizada el Día1

Recuerde renombrar los archivos file1.java, file2.java, file3.java