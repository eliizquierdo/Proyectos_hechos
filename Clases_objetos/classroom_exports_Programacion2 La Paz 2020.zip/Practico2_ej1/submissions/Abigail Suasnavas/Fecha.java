   public class 
  private string fecha;
  private int dia;
  private int mes;
  private int anio;
  
  
  //constructor por defecto//
  public Fecha()  { 
  anio=2020;
  }
  
  //constructor especifico//
  public Fecha(String d, int m, int a)  {
  dia=d;
  mes=m;
  anio=a;
  
  }
  //metodos getter
  public String GetDia()   {
    return dia;
  }
  
  public int GetMes()    {
   return mes;
  }
  
  public int GetAnio()   {
    return anio;
  }
   
   //metodo setter
   public void SetDia(String d) {
     dia=d;
   }
   pubic void SetMes(String m) {
     mes=m;
   {
     public void SetAnio(String a) {
       anio=a;
     }
    //metodo especifico
   //si el día es 13, el mes 12 y el año 2020, entonces devuelve: "13/12/2020".
   public string fecha() {
    string dia; 
    if (anio<2020)
        dia=mes*13/12;
    else 
        mes=anio*12/2020;
        
        
        
   return fecha;
   
   } 
   
   
   @Override
   public String toString()  { 
    return "Dia:  +" dia +" \nMes: "+ Mes +" \nAnio: " +anio;  
        
   }
   }
  
