
import java.util.Scanner;


public class Articulo {
	
	private int codigo;
	private String nombre;
	private double precioCosto;
	private file4 vencimiento;
		
	public Articulo() {
		vencimiento=new file4();
			
	}
		
	public Articulo(int codigo, String nombre, double precioCosto,file4 vencimiento) {
			this.codigo = codigo;
			this.nombre = nombre;
			this.precioCosto = precioCosto;
			this.vencimiento = vencimiento;
	}
		
		

	public int getCodigo() {
			return codigo;
	}

	public void setCodigo(int codigo) {
			this.codigo = codigo;
	}

	public String getNombre() {
			return nombre;
	}

	public void setNombre(String nombre) {
			this.nombre = nombre;
	}

	public double getPrecioCosto() {
			return precioCosto;
	}

	public void setPrecioCosto(double precioCosto) {
			this.precioCosto = precioCosto;
	}

		public file4 getVencimiento() {
		return vencimiento;
	}

	public void setVencimiento(file4 vencimiento) {
		this.vencimiento = vencimiento;
	}

		public double precioVenta() {
			double precioVenta;
			precioVenta = precioCosto + (precioCosto*20/100);
			return precioVenta;
		}
		
	
		@Override
		public String toString() {
			return "Codigo: " + codigo + "\nNombre: " + nombre + "\nPrecio de venta: "+"vencimiento= "+ vencimiento.toString() + precioVenta();
		}
}