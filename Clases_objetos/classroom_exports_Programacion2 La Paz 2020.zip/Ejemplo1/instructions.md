 **Escribe el código que falta para que:**
1) Diga Hola mundo!! en vez de Hello world!2) Pregunte el nombre y la edad y guarde3) Muestre en pantalla los datos guardados anteriormente siguiendo el formato:


```
Su nombre es: **xxxx** y su edad es:  **xxx**
```